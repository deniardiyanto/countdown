# New-Year-Eve-Countdown-Timer
<p>New Year CountDown timer is a simple javascript application that visualize or count the day to the New Year Eves</p>

<h2>Neat Interface</h2>
<img src="./images/eve-image.PNG" align="center">
<br/>

<h2>Usage</h2>
<p>Git Clone: To clone the Repository</p>
<p>Open with your favourite IDE</p><br>

<h2>Live Demo</h2>
<a target="_blank" href="https://davidolaoluwa360.github.io/new-year-eve-countdown-timer/">View New Year CountDown Timer</a>
#   c o u n t d o w n  
 